import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTheme } from '../../../ThemeContext';
import ThemeSwitch from '../../componentes/themeSwitch';
import { useNavigation } from '@react-navigation/native';
import { getStyles } from '../../estilos/styles';

import Icon from 'react-native-vector-icons/FontAwesome'; // Importamos el paquete para los íconos
import Icon2 from 'react-native-vector-icons/Ionicons'; // Importamos los íconos
import MenuModal from '../../componentes/MenuModal'; // Ajusta la ruta según la ubicación del archivo
// import styles from './FacturacionesScreen.styles'; // Importa los estilos desde un archivo separado
import HorizontalMenu from '../../componentes/HorizontalMenu'; // Ajusta la ruta según la ubicación del archivo

const ProgressBar = ({ progress }) => {
  const { isDarkMode } = useTheme();
  const styles = useStyles(isDarkMode);

  return (
    <View style={styles.progressBar}>
      <View style={[styles.progressBarFill, { width: `${progress}%` }]}>
        <View style={styles.progressBall}></View>
      </View>
    </View>
  );
};

const MoneyProgressBar = ({ amountProgress }) => {
  const { isDarkMode } = useTheme();
  const styles = useStyles(isDarkMode);

  return (
    <View style={styles.moneyProgressBar}>
      <View style={[styles.moneyProgressBarFill, { width: `${amountProgress}%` }]}></View>
    </View>
  );
};

const FacturacionesScreen = () => {
  const [ciclos, setCiclos] = useState([]);
  const { isDarkMode, toggleTheme } = useTheme();
  const styles = getStyles(isDarkMode);
  const navigation = useNavigation();
  const [nombreUsuario, setNombreUsuario] = useState('');
  const [usuarioId, setUsuarioId] = useState(null);
  const [ispId, setIspId] = useState('');
  const [facturacionPermiso, setFacturacionPermiso] = useState('basica');
  const [menuVisible, setMenuVisible] = useState(false);
  // const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const obtenerIspId = async () => {
      try {
        const id = await AsyncStorage.getItem('@selectedIspId');
        setIspId(id || 'No ID');
      } catch (error) {
        console.error('Error al recuperar el ID del ISP', error);
      }
    };

    obtenerIspId();
  }, []);

  useEffect(() => {
    const obtenerDatosUsuario = async () => {
      try {
        const jsonValue = await AsyncStorage.getItem('@loginData');
        const userData = jsonValue != null ? JSON.parse(jsonValue) : null;
        if (userData) {
          setNombreUsuario(userData.nombre);
          setUsuarioId(userData.id);
        }
      } catch (e) {
        console.error('Error al leer el nombre del usuario', e);
      }
    };

    obtenerDatosUsuario();
  }, []);

  useEffect(() => {
    const registrarNavegacion = async () => {
      if (!usuarioId) {
        console.error('No se puede registrar la navegación sin un id_usuario válido.');
        return;
      }

      try {
        const fechaActual = new Date();
        const fecha = fechaActual.toISOString().split('T')[0]; // Formato YYYY-MM-DD
        const hora = fechaActual.toTimeString().split(' ')[0]; // Formato HH:mm:ss

        const logData = {
          id_usuario: usuarioId,
          fecha,
          hora,
          pantalla: 'FacturacionesScreen',
          datos: JSON.stringify({ modo: isDarkMode ? 'Oscuro' : 'Claro' }),
        };

        const response = await axios.post('https://wellnet-rd.com:444/api/log-navegacion-registrar', logData);

        if (response.status !== 201) {
          throw new Error(response.data.message || 'Error al registrar la navegación');
        }

        console.log('Navegación registrada exitosamente');
      } catch (error) {
        console.error('Error al registrar la navegación:', error);
      }
    };

    if (usuarioId) {
      registrarNavegacion();
    }
  }, [usuarioId, isDarkMode]);



  const cargarCiclos = async () => {
    try {
      const response = await axios.post('https://wellnet-rd.com:444/api/ciclos-incompleto', {
        id_isp: ispId,
      });
      setCiclos(response.data.reverse());
    } catch (error) {
      console.error('Error al realizar la petición:', error);
    }
  };

  const obtenerPermisos = async () => {
    try {
      const response = await axios.post('https://wellnet-rd.com:444/api/usuarios/obtener-permisos-usuario', {
        id_usuario: usuarioId,
      });
      const permisosData = response.data;
      const permisoFacturacion = permisosData.find((permiso) => permiso.permiso === 'permiso_facturaciones');
      if (permisoFacturacion) {
        setFacturacionPermiso(permisoFacturacion.vista);
      }
    } catch (error) {
      console.error('Error al obtener permisos del usuario:', error);
    }
  };

  useEffect(() => {
    if (ispId && usuarioId) {
      cargarCiclos();
      obtenerPermisos();
      // registrarNavegacion('FacturacionesScreen', { ispId, usuarioId });
    }
  }, [ispId, usuarioId]);

  // useEffect(() => {
  //   registrarNavegacion('Cambio de modo en FacturacionesScreen', { modo: isDarkMode ? 'Oscuro' : 'Claro' });
  // }, [isDarkMode]);


  const formatDate = (dateString) => {
    if (!dateString) return 'Fecha inválida';
    const date = new Date(dateString);
    return date.toLocaleDateString('es-DO', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      timeZone: 'America/Santo_Domingo', // Zona horaria para República Dominicana
    });
  };




  // const formatDate = (isoString) => {
  //   if (!isoString) return '';
  //   const date = new Date(isoString);
  //   const options = { day: '2-digit', month: 'long', year: 'numeric' };
  //   return new Intl.DateTimeFormat('es-ES', options).format(date);
  // };


  // const formatDate = (isoString) => {
  //   if (!isoString) return '';
  //   const date = new Date(isoString);
  //   const day = `0${date.getDate()}`.slice(-2);
  //   const month = `0${date.getMonth() + 1}`.slice(-2);
  //   const year = date.getFullYear();
  //   return `${day}/${month}/${year}`;
  // };

  const formatMoney = (amount) => {
    return new Intl.NumberFormat('es-DO', {
      style: 'currency',
      currency: 'DOP',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const determineBackgroundColor = (startDate, endDate) => {
    const currentDate = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);
    const daysDifference = Math.floor((currentDate - end) / (1000 * 60 * 60 * 24));

    if (currentDate >= start && currentDate <= end) {
      return styles.inTimeBackground; // Green
    } else if (currentDate > end && daysDifference <= 10) {
      return styles.nearDueBackground; // Yellow
    } else if (currentDate > end && daysDifference > 10) {
      return styles.overDueBackground; // Red
    } else {
      return styles.defaultBackground; // Default
    }
  };

  const renderItem = ({ item }) => {
    const backgroundColor = determineBackgroundColor(item.inicio, item.final);
    const totalDays = (new Date(item.final) - new Date(item.inicio)) / (1000 * 60 * 60 * 24);
    const currentDay = (new Date() - new Date(item.inicio)) / (1000 * 60 * 60 * 24);
    const progress = Math.min(Math.max((currentDay / totalDays) * 100, 0), 100);

    const amountProgress = Math.min(Math.max((item.dinero_cobrado / item.total_dinero) * 100, 0), 100);

    return (
      <TouchableOpacity
        style={[styles.itemContainer, backgroundColor]}
        onPress={() => navigation.navigate('DetalleCicloScreen', { ciclo: item })}
      >
        {/* <Text style={styles.itemName}>Ciclo ID: {item.id_ciclo}</Text> */}
        <Text style={styles.itemName}>{formatDate(item.inicio)} hasta {formatDate(item.final)}</Text>
        {facturacionPermiso === 'avanzada' && (
          <>
            <ProgressBar progress={progress} />
           
            <Text style={styles.itemDetails}>
              Facturas Pendiente: {item.facturas_pendiente} de {item.total_facturas}
            </Text>
            <Text style={[styles.itemDetails, styles.boldText]}>
              Ingreso: {formatMoney(item.dinero_cobrado)} de {formatMoney(item.total_dinero)}
            </Text>
            <MoneyProgressBar amountProgress={amountProgress} />
  
            <Text style={[styles.itemDetails, { fontWeight: 'bold', fontSize: 24 }]}>
              Faltante por Cobrar: {formatMoney(item.total_dinero - item.dinero_cobrado)}
            </Text>


          </>
        )}
      </TouchableOpacity>
    );
  };

  // if (loading) {
  //   return (
  //     <View style={styles.loadingContainer}>
  //       <ActivityIndicator size="large" color="#BB86FC" />
  //     </View>
  //   );
  // }


  // Botones del menú horizontal
  const botones = [
    { id: '5', screen: 'BusquedaScreen', icon: 'search' }, // Botón de búsqueda
    { id: '4', action: () => setMenuVisible(true), icon: 'bars' },
    { id: '1', title: 'Base de ciclos', screen: 'BaseCicloScreen' },
    { id: '2', title: 'Revisiones', screen: 'FacturasEnRevisionScreen', params: { id_isp: ispId, estado: 'en_revision' } },
    { id: '3', title: 'Ingresos', screen: 'IngresosScreen', icon: 'dollar' }, // Ejemplo de otro icono
    {
      id: '7',
      screen: null, // Dejarlo en null si solo realiza una acción
      icon: isDarkMode ? 'sun-o' : 'moon-o', // Cambiar entre 'sun-o' y 'moon-o' basado en isDarkMode
      action: () => {
        toggleTheme(); // Lógica para cambiar el modo oscuro (debes tener esta función definida)
      },
    },
  ];

  // onPress={() => navigation.navigate('BaseCicloScreen')






  // <TouchableOpacity style={styles.button} onPress={() => { /* Acción si se requiere */ }}>
  //   <Text style={styles.buttonText}>{nombreUsuario || 'Usuario'}</Text>
  // </TouchableOpacity>


  return (
    <>
      {/* <View style={styles.containerSuperior}>
      <Text style={styles.title}>Ciclos</Text>
      <ThemeSwitch />
    </View> */}

      <View style={styles.container}>
        <FlatList
          data={ciclos}
          keyExtractor={(item) => item.id_ciclo.toString()}
          renderItem={renderItem}
        />
      </View>

      <View style={styles.containerSuperior}>
        {/* <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('BaseCicloScreen')}>
          <Text style={styles.statusButton}>Base de ciclos</Text>
        </TouchableOpacity> */}
        {/* <TouchableOpacity
          style={styles.footerButton}
          onPress={() => navigation.navigate('FacturasEnRevisionScreen', { id_isp: ispId, estado: 'en_revision' })}
        >
          <Text style={styles.statusButton}>Revisiones</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.footerButton} onPress={() => navigation.navigate('IngresosScreen')}>
          <Text style={styles.statusButton}>Ingresos</Text>
        </TouchableOpacity> */}









      </View>
      {/* Menú Horizontal Reutilizable */}
      <HorizontalMenu botones={botones} navigation={navigation} isDarkMode={isDarkMode} />


      {/* Modal del Menú */}
      <MenuModal
        visible={menuVisible}
        onClose={() => {
          setMenuVisible(false);
          // Refrescar el estado del tema cuando se cierra el modal
          const refreshTheme = async () => {
            try {
              const theme = await AsyncStorage.getItem('@theme');
              setIsDarkMode(theme === 'dark');
            } catch (error) {
              console.error('Error al cargar el tema', error);
            }
          };
          refreshTheme();
        }}
        menuItems={[
          { title: 'Inicio', action: () => navigation.navigate('HomeScreen') },
          { title: 'Perfil', action: () => navigation.navigate('ProfileScreen') },
          { title: 'Configuración', action: () => navigation.navigate('SettingsScreen') },
          { title: 'Cerrar Sesión', action: () => console.log('Cerrando sesión') },
        ]}
        isDarkMode={isDarkMode}
        onItemPress={(item) => {
          item.action();
          setMenuVisible(false);
        }}
      />
    </>
  );
};

const useStyles = (isDarkMode) =>
  StyleSheet.create({
    progressBarContainer: {
      marginTop: 10,
      marginBottom: 20,
    },
    progressBar: {
      height: 10,
      width: '100%',
      backgroundColor: isDarkMode ? '#444' : '#ddd',
      borderRadius: 5,
      overflow: 'hidden',
      marginBottom: 5,
    },
    progressBarFill: {
      height: '100%',
      backgroundColor: isDarkMode ? '#888' : '#bbb',
      position: 'relative',
    },
    progressBall: {
      height: 20,
      width: 20,
      backgroundColor: isDarkMode ? 'white' : 'blue',
      borderRadius: 10,
      position: 'absolute',
      top: -5,
      right: -10,
    },
    moneyProgressBar: {
      height: 10,
      width: '100%',
      backgroundColor: isDarkMode ? '#666' : '#ccc',
      borderRadius: 5,
      marginTop: 5,
      overflow: 'hidden',
    },
    moneyProgressBarFill: {
      height: '100%',
      backgroundColor: isDarkMode ? '#00FF00' : '#00AA00',
    },
    boldText: {
      fontWeight: 'bold',
    },
    largeText: {
      fontSize: 18,
    },
    footer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      padding: 10,
      borderTopWidth: 1,
      borderTopColor: isDarkMode ? '#444' : '#ddd',
      backgroundColor: isDarkMode ? '#333' : '#f4f4f4',
      marginTop: 10, // Asegura que no se superponga
    },
    footerButton: {
      flex: 1,
      alignItems: 'center',
      paddingVertical: 10,
      marginHorizontal: 5,
      backgroundColor: isDarkMode ? '#007bff' : '#007bff', // Color azul para dar contraste
      borderRadius: 5,
    },
    footerButtonText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: 'bold',
    },
  });

export default FacturacionesScreen;
