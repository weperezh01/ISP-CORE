import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Alert,
    ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AgregarArticuloPantalla = ({ route }) => {
    const navigation = useNavigation();
    const [descripcion, setDescripcion] = useState('');
    const [cantidad, setCantidad] = useState('');
    const [precioUnitario, setPrecioUnitario] = useState('');
    const [codigo, setCodigo] = useState('');
    const [isDarkMode, setIsDarkMode] = useState(false);
    const { id_factura } = route.params;
    const [nombreUsuario, setNombreUsuario] = useState('');
    const [usuarioId, setUsuarioId] = useState(null);

    // Cargar el modo inicial desde AsyncStorage
    useEffect(() => {
        const loadTheme = async () => {
            try {
                const theme = await AsyncStorage.getItem('@theme'); // Obtiene el tema
                const isDark = theme === 'dark';
                setIsDarkMode(isDark);
            } catch (error) {
                console.error('Error al cargar el tema', error);
            }
        };
        loadTheme();
    }, []);

    useEffect(() => {
        const obtenerDatosUsuario = async () => {
            try {
                const jsonValue = await AsyncStorage.getItem('@loginData');
                const userData = jsonValue != null ? JSON.parse(jsonValue) : null;
                if (userData) {
                    setNombreUsuario(userData.nombre);
                    setUsuarioId(userData.id);
                }
            } catch (e) {
                console.error('Error al leer el nombre del usuario', e);
            }
        };

        obtenerDatosUsuario();
    }, []);

    console.log('id_factura', id_factura);
    console.log('nombreUsuario', nombreUsuario);
    console.log('usuarioId', usuarioId);

    const handleAgregarArticulo = async () => {
        if (!descripcion || !cantidad || !precioUnitario || !codigo) {
            Alert.alert('Error', 'Por favor complete todos los campos.');
            return;
        }

        if (!usuarioId) {
            Alert.alert('Error', 'No se pudo obtener el ID de usuario.');
            return;
        }

        const nuevoArticulo = {
            usuarioId,
            id_factura,
            descripcion,
            cantidad: parseInt(cantidad),
            precio_unitario: parseFloat(precioUnitario),
            codigo: parseInt(codigo),
        };

        try {
            // Realizar la solicitud POST al backend para insertar el artículo
            const response = await fetch('https://wellnet-rd.com/api/insertar-articulo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(nuevoArticulo),
            });

            if (response.ok) {
                Alert.alert('Éxito', 'Artículo agregado correctamente.');
                navigation.goBack();
            } else {
                const errorData = await response.json();
                Alert.alert('Error', errorData.error || 'No se pudo agregar el artículo.');
            }
        } catch (error) {
            console.error('Error al agregar el artículo:', error);
            Alert.alert('Error', 'Error al comunicarse con el servidor.');
        }
    };

    const styles = getStyles(isDarkMode);

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Agregar Nuevo Artículo</Text>

            <Text style={styles.label}>Código</Text>
            <TextInput
                style={styles.input}
                value={codigo}
                onChangeText={setCodigo}
                placeholder="Código del artículo"
                keyboardType="numeric"
                placeholderTextColor="#888"
            />

            <Text style={styles.label}>Descripción</Text>
            <TextInput
                style={styles.input}
                value={descripcion}
                onChangeText={setDescripcion}
                placeholder="Descripción del artículo"
                placeholderTextColor="#888"
            />

            <Text style={styles.label}>Cantidad</Text>
            <TextInput
                style={styles.input}
                value={cantidad}
                onChangeText={setCantidad}
                placeholder="Cantidad"
                keyboardType="numeric"
                placeholderTextColor="#888"
            />

            <Text style={styles.label}>Precio Unitario</Text>
            <TextInput
                style={styles.input}
                value={precioUnitario}
                onChangeText={setPrecioUnitario}
                placeholder="Precio Unitario"
                keyboardType="numeric"
                placeholderTextColor="#888"
            />

            <TouchableOpacity style={styles.button} onPress={handleAgregarArticulo}>
                <Text style={styles.buttonText}>Agregar Artículo</Text>
            </TouchableOpacity>
        </ScrollView>
    );
};

const getStyles = (isDarkMode) => StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: isDarkMode ? '#333' : '#fff',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        color: isDarkMode ? '#fff' : '#000',
    },
    label: {
        fontSize: 16,
        marginBottom: 10,
        color: isDarkMode ? '#ddd' : '#333',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        fontSize: 16,
        marginBottom: 20,
        color: isDarkMode ? '#fff' : '#000',
        backgroundColor: isDarkMode ? '#555' : '#fff',
    },
    button: {
        backgroundColor: '#007bff',
        padding: 15,
        alignItems: 'center',
        borderRadius: 5,
    },
    buttonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});

export default AgregarArticuloPantalla;
